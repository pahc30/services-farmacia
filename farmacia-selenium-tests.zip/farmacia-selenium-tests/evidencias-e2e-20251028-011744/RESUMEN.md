# Reporte de Pruebas E2E - Farmacia Dey

**Fecha:** 2025-10-28 01:19:59
**Branch:** feature/tests-caja-negra
**Commit:** 7dfe1f1

## Servicios Backend

- ✅ **auth** (puerto 7011): HTTP 403
- ✅ **usuario** (puerto 7012): HTTP 200
- ✅ **producto** (puerto 7013): HTTP 200
- ✅ **metodopago** (puerto 7014): HTTP 200
- ✅ **compra** (puerto 7015): HTTP 200
- ✅ **frontend** (puerto 4200): HTTP 200

## Frontend

- ✅ **Angular App** (puerto 4200): Activo

## Pruebas de Autenticación

- ✅ Login API: Exitoso con credenciales test1/test1
- Token JWT generado correctamente

## Pruebas Selenium (E2E)

Tests run: 6, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 131.8 s -- in pe.com.farmaciadey.selenium.FarmaciaDeYTests

## Evidencias Generadas

- `servicios-status.txt` - Estado de servicios
- `login-response.json` - Respuesta de login API
- `selenium-output.txt` - Log completo de Selenium
- `selenium-screenshots/` - Capturas de pantalla
- `surefire-reports/` - Reportes XML/TXT de JUnit

## Conclusión

✅ **TODAS LAS PRUEBAS PASARON EXITOSAMENTE**

