# 🧪 Farmacia Dey - Pruebas E2E con Selenium

Repositorio dedicado a las pruebas End-to-End (E2E) del sistema de gestión de Farmacia Dey utilizando Selenium WebDriver.

## 📋 Descripción

Este proyecto contiene pruebas automatizadas de caja negra que validan el funcionamiento completo del sistema Farmacia Dey, incluyendo:

- ✅ Autenticación de usuarios
- ✅ Listado y búsqueda de productos
- ✅ Carrito de compras
- ✅ Perfil de usuario
- ✅ Métodos de pago
- ✅ Historial de compras

## 🏗️ Arquitectura del Sistema Bajo Prueba

### Backend (Spring Boot 3.5.6)
- **auth** (puerto 7011) - Autenticación y JWT
- **usuario** (puerto 7012) - Gestión de usuarios
- **producto** (puerto 7013) - Catálogo de productos
- **metodopago** (puerto 7014) - Métodos de pago
- **compra** (puerto 7015) - Gestión de compras

### Gateway & Frontend
- **Spring Cloud Gateway** (puerto 9000) - API Gateway
- **Angular 18** (puerto 4200) - Interfaz web

## 🚀 Prerequisitos

- **Java 21**
- **Maven 3.9+**
- **Chrome/Chromium** instalado
- **Sistema backend** ejecutándose (todos los microservicios + gateway + frontend)

## ⚙️ Configuración

### 1. Clonar el repositorio

```bash
git clone <repository-url>
cd farmacia-selenium-tests
```

### 2. Compilar el proyecto

```bash
mvn clean compile
```

## 🧪 Ejecutar las Pruebas

### Opción 1: Script automático (recomendado)

```bash
chmod +x ejecutar-pruebas-e2e.sh
./ejecutar-pruebas-e2e.sh
```

### Opción 2: Maven directo

```bash
mvn clean test
```

### Opción 3: Ejecutar una prueba específica

```bash
mvn test -Dtest=FarmaciaDeYTests#testLoginFlow
```

## 📊 Resultados

### Últimas Ejecuciones

**Fecha:** 28 de Octubre de 2025
- ✅ **6/6 pruebas exitosas** (100%)
- ⏱️ **Tiempo total:** 131.8 segundos
- 📸 **Evidencias:** 13 screenshots generados

Ver reportes completos en:
- `REPORTE-PRUEBAS-E2E.md`
- `REPORTE-PRUEBAS-E2E-FINAL.md`

## 📁 Estructura del Proyecto

```
farmacia-selenium-tests/
├── src/
│   └── test/
│       └── java/
│           └── pe/com/farmaciadey/selenium/
│               └── FarmaciaDeYTests.java
├── evidencias-e2e-*/          # Screenshots y reportes por ejecución
├── ejecutar-pruebas-e2e.sh   # Script de ejecución automática
├── REPORTE-PRUEBAS-E2E.md    # Reporte detallado
└── pom.xml                    # Configuración Maven
```

## 🔧 Tecnologías

- **Selenium WebDriver 4.31.0** - Automatización del navegador
- **WebDriverManager 5.9.2** - Gestión automática de drivers
- **JUnit 5** - Framework de testing
- **Maven Surefire** - Ejecución y reportes de pruebas
- **Chrome Headless** - Navegador sin interfaz gráfica

## 📸 Evidencias

Cada ejecución genera automáticamente:
- Screenshots de pasos importantes
- Reportes JUnit (XML/TXT)
- Logs detallados de Selenium
- HTML sources de páginas visitadas
- Resumen en formato Markdown

## 🤝 Contribuir

1. Fork el proyecto
2. Crea tu feature branch (`git checkout -b feature/nueva-prueba`)
3. Commit tus cambios (`git commit -m 'Agregar nueva prueba de X'`)
4. Push al branch (`git push origin feature/nueva-prueba`)
5. Abre un Pull Request

## 📝 Casos de Prueba Implementados

### 1. testLoginFlow
Verifica el flujo completo de autenticación con credenciales válidas.

### 2. testProductListing
Valida la visualización del catálogo de productos.

### 3. testAddToCartFlow
Prueba la funcionalidad de agregar productos al carrito.

### 4. testUserProfile
Verifica la visualización del perfil del usuario logueado.

### 5. testPaymentMethods
Valida el acceso a la configuración de métodos de pago.

### 6. testPurchaseHistory
Verifica el acceso al historial de compras del usuario.

## 🔗 Enlaces

- **Repositorio Backend:** [services-farmacia](https://github.com/pahc30/services-farmacia)
- **Documentación API:** http://localhost:9000/swagger-ui.html (cuando el sistema está activo)

## 👥 Equipo

Proyecto desarrollado para el curso de Integrador II - UTP - Ciclo 09

---

**Última actualización:** 28 de Octubre de 2025
