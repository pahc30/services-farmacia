package pe.com.farmaciadey.compra.utils;

public class Utils {
    public final static Integer REQUEST_OK = 1;
    public final static Integer REQUEST_ERROR = 0;
    public final static String BASE_URL_PRODUCTO = "http://localhost:7003/producto";
    public final static String BASE_URL_METODO_PAGO = "http://localhost:7004/metodopago";
}
