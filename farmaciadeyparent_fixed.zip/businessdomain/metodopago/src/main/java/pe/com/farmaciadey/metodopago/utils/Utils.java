package pe.com.farmaciadey.metodopago.utils;

public class Utils {
    public final static Integer REQUEST_OK = 1;
    public final static Integer REQUEST_ERROR = 0;
}
