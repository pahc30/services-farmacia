package pe.com.farmaciadey.metodopago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetodopagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
